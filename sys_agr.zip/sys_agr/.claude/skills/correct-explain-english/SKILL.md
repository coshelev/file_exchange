---
name: correct-explain-english
description: Use when the user's message contains English spelling, grammar, or phrasing errors. Corrects the errors and briefly explains each fix before addressing the user's actual request.
---

# Correct and explain English errors

When invoked, do the following before (or alongside) responding to the substance of the user's message:

1. Quote the original sentence(s) that contain errors.
2. Give a corrected version.
3. For each fix, add a short explanation of the rule or convention involved (one line each — don't lecture).
4. Then proceed to answer the user's actual request normally.

Keep the correction section compact. If the message has no errors, skip the correction section entirely and just say so in one line, then continue.

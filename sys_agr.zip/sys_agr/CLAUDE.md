# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A **1C:Enterprise 8.3** configuration (platform ≥ 8.3.27). The product is "Система управления услугами ОИТ (Агрегатор)" — IT Department Service Management System for ООО "Луидор" (auto dealer), version 10.00.

All business logic is written in **BSL** (1C Business Script Language, Russian keywords). Metadata definitions are XML files. The scripting language variant is Russian (`ScriptVariant=Russian`), so all identifiers, procedure/function names, and keywords are in Russian.

## Development workflow

There are no CLI build, lint, or test commands — this configuration is developed and deployed through **1C:Enterprise Designer (Конфигуратор)**. Typical operations:

- **Load into designer**: open the infobase in 1C:Enterprise Designer, then load the XML dump via *Configuration → Load Configuration from Files*
- **Save changes back to files**: *Configuration → Save Configuration to Files* (produces the XML + BSL files in this repo)
- **Run / debug**: launch a test infobase client from Designer

## Repository layout

Each 1C metadata object has its own directory + a paired `.xml` (metadata declaration) and a nested `Ext/` directory (BSL source code, forms, etc.).

| Directory | Contains |
|---|---|
| `CommonModules/*/Ext/Module.bsl` | Shared server/client/common modules — the bulk of business logic |
| `ScheduledJobs/` | Background job definitions (metadata only; logic lives in CommonModules) |
| `Reports/` | Report definitions and query layouts |
| `Catalogs/` | Reference books (справочники) |
| `InformationRegisters/` | Information registers (РегистрыСведений) |
| `DataProcessors/` | Data processors and operator workplaces |
| `BusinessProcesses/` | Loyalty feedback business processes |
| `Tasks/` | Task objects (ЗадачаОбратнаяСвязь, ЗадачиИсполнителей) |
| `HTTPServices/` | HTTP service endpoints exposed by the infobase |
| `WebServices/` | SOAP web services |
| `IntegrationServices/` | Integration service (МатрицаАгрегатор) |
| `ExternalDataSources/` | External DB connections (Asterisk CDR tables, stat DB) |
| `Ext/ManagedApplicationModule.bsl` | Application startup/shutdown entry point |
| `Ext/SessionModule.bsl` | Session parameter initialization |

## Architecture and key modules

### Module naming convention
CommonModules follow a suffix pattern:
- No suffix — runs on server and client (общий, &НаКлиентеНаСервере context)
- `Сервер` suffix — server-only code
- `Клиент` suffix — thin client / browser-only code
- `КлиентСервер` suffix — available on both contexts

### Core domain modules

| Module | Role |
|---|---|
| `ОбщНазн` | General-purpose utilities: `ВыполнитьЗапрос`, `ЗаписатьСобытие`, etc. Used everywhere |
| `ЗначенияСервера` | Session parameter storage/retrieval (`ПолучитьЗначениеПараметраСеанса`) |
| `Конвертация` / `КонвертацияСервер` | Type-conversion helpers (phone refs, queue refs, etc.) |
| `ДоступСервер` | User access rights: which target points (ЦелевыеТочки) a user may read |

### Telephony subsystem
- `Телефония` / `ТелефонияКлиент` — Asterisk PBX component wrapper (Native external component `КомпонентаТелефонии` via `ОбщийМакет.КомпонентаТелефонии`)
- `КонтактЦентр` / `КонтактЦентрСервер` — contact center operator console logic
- `ОчередиАгенты` — reads Asterisk queues and agents directly from external data sources (`ВнешниеИсточникиДанных.AsteriskNnov`, `AsteriskEdge`)
- `ЗвонкиРасшифровка` — call transcription
- External data sources **AsteriskNnov** and **AsteriskEdge** expose CDR tables `ЗвонкиВходящие` / `ЗвонкиИсходящие`

### Integration modules
- `Авито` — low-level HTTP client and Avito Messenger API; also contains `GreenApiWhatsapp_SendMessage` for WhatsApp via Green-API
- `АвитоКлиент` — client-side Avito helpers
- `ВэбСервисы` — inbound webhook handlers: JivoSite chat events, Avito messages, etc.
- `ЭлПочта` / `ЭлПочтаКлиент` — reads Yandex mailboxes; credentials stored in `РегистрыСведений.УчетнаяПолитика` and cached in `ХранилищеОбщихНастроек`
- `ИнтернетЗаявки` — parses web-lead JSON from classifieds (Авито, Автоброкер, etc.)
- `ОтказныеЗвонки` / `ОтказныеСделки` — loads missed-call and rejected-deal records from the operational DB via JSON-RPC over curl

### Task routing
- `ПроцессыСервер` — assigns executors to roles+departments via `РегистрыСведений.АдресацияЗадач`
- `ЗадачиСервер` / `ЗадачиАктивныхПродаж` — task lifecycle helpers

### HTTP / Web services exposed
- **`HTTPServices/jsonRest`** — JSON REST endpoint
- **`HTTPServices/Вэбхуки`** — webhook receiver
- **`WebServices/CallFromSite`**, **`Notification`**, **`ОбщегоНазначения`** — SOAP services
- **`IntegrationServices/МатрицаАгрегатор`** — integration service bus endpoint

### Scheduled jobs (background automation)
Jobs are defined in `ScheduledJobs/*.xml` and implemented in CommonModules. Key examples:
- `ЗвонкиЗагрузить` — loads Asterisk CDR events; called daily at ~05:40
- `КонтрагентыОбновить` / `КонтрагентыСотрудникиЗагрузить` — syncs counterparties/employees from operational DB
- `ПисьмаЗагрузить` — reads incoming email
- `ЗвонкиЦелевыеРасшифровать` — triggers call transcription pipeline
- `ОчередьЗаданийОбработка` — main background task queue processing
- `ОчередьВЛокальныйРежим_*` / `ОчередьИзЛокальногоРежима_*` — switches infobase between online/offline queue modes at scheduled times

## Conventions observed in the codebase

- Queries use the 1C query language (ВЫБРАТЬ / SELECT with Russian keywords); inline SQL strings are assembled with `СтрШаблон`.
- External HTTP calls go through `Авито.CURL_Str(кмд)` where `кмд` is a string written in curl command syntax (e.g. `curl -X POST 'https://...' -H '...' -d '...'`). This is **not** a real shell call — `Авито.CURL` is a hand-written parser in `CommonModules/Авито` that lexes the curl string and executes the request via 1C's native `HTTPСоединение` + `HTTPЗапрос`. Curl syntax is the DSL for authoring HTTP calls throughout the codebase.
- Error handling pattern: wrap in `Попытка/Исключение`, write to journal via `ЗаписьЖурналаРегистрации(...)`.
- Guard clauses validate argument types with `ТипЗнч(X) = Тип("...")` before proceeding.
- `#Область / #КонецОбласти` preprocessor regions are used to group code (e.g. `#Область ROMAsterisk`).
- Session parameters (current user, telephone, mode) are passed through `ЗначенияСервера` rather than global variables where possible.

﻿Функция DataGet(PhoneNum, Site, Extra = "")
	//Функция web-сервиса CallFromSite (http://mainappl/sys_agr/ws/CallFromSite?wsdl)
	//Регистрирует интернет-заявку и выполняет автозвонок  (http://mainappl/sys_agr/ws/CallFromSite?wsdl)	 
	Возврат ВэбСервисы.DataGet(PhoneNum, Site, Extra);
КонецФункции

Функция LeadGenic(prop)
	Возврат "test";
КонецФункции
